# Reapplying the Verne document analysis

Gülsüm Meço • EduAI2027 • Paper 13803

This supplement lets readers trace each recorded classification to a paragraph, recalculate the reported figures, and adapt the search and sampling procedure to another text. The analysis unit is a paragraph. A curriculum match is a paragraph–outcome pair, with a distinct record for each proposed outcome.

## Recalculate the study results

Unzip the entire package. From this folder, run the following with Python 3.8 or newer.

```sh
python verify_results.py
```

The command reads the CSV files in `data/` and prints a JSON summary. It uses only the Python standard library. The source records yield 1,680 unique paragraphs, 659 keyword candidates, a three-class pilot matrix with 29 diagonal entries in 50 records, and 62 scored curriculum pairs. Code 0 is a recorded judgment. An empty curriculum score marks an unscored pair.

### Using Google Colab

Open a blank Colab notebook and run the following cell. Select the supplied supplement ZIP when prompted. The script reads the archived CSV records and prints the results directly under the cell.

```python
from google.colab import files
from pathlib import Path
from zipfile import ZipFile
import subprocess
import sys

uploaded = files.upload()
archive_name = next(name for name in uploaded if name.lower().endswith(".zip"))
folder = Path("verne_materials")
with ZipFile(archive_name) as archive:
    archive.extractall(folder)
subprocess.run([sys.executable, str(folder / "verify_results.py")], check=True)
```

## Adapt the procedure

1. Prepare a UTF-8 CSV with columns `paragraph_id,text`. Retain original order and wording. Record the edition and your rule for removing front matter. The study corpus appears in `data/paragraphs.csv`, with its original IDs (P4 onward).
2. Edit a copy of `example_dictionary.csv`. Each row contains a group and a case-insensitive Python regular expression. The example is a new, small teaching dictionary. Fifteen of its literal terms appear in the original 20-passage matching sheet. Four supplementary terms illustrate extending a search. A historical search with a different dictionary can select different paragraphs.
3. Run the command below, using a new output directory. The default sample draws six distinct paragraphs per group and 20 nonmatches with seed 20261015. For this implementation, groups with smaller candidate pools are sampled first. Set `--per-group`, `--nonmatches`, and `--seed` to adapt the design. The study’s actual pilot IDs and strata are preserved in `data/pilot.csv`.

```sh
python screen_new_corpus.py --paragraphs data/paragraphs.csv --dictionary example_dictionary.csv --output new_screen
```

4. Give the coder only `new_screen/pilot_blind.csv`. Ask for a code and the words or observation that support it. Preserve these entries before showing any earlier labels. The other two output files contain keyword evidence and the sampling key.
5. Use the separate content and curriculum criteria in `method_and_prompts.md` for contextual review. Store any AI suggestion with the prompt, model identifier, run date and its rationale. Keep a separate field for a researcher’s final decision. If a second independent human coder participates, retain each person’s pre-discussion decisions.

## What was archived

| Material | Provenance and use |
| --- | --- |
| `original/NLP_Odev1_Gulsum_Meco.ipynb` | Original Colab notebook for retrieval and lexical preprocessing of Gutenberg eBook 164. It also contains the author’s frequency, n-gram and word-cloud analyses. Its retrieval cells need network access. Word-frequency outputs cover the notebook’s text and are distinct from the 1,680-paragraph screening dataset. |
| `verify_results.py` | New, tested calculation script for the archived study records. |
| `screen_new_corpus.py` and `example_dictionary.csv` | New, tested reference implementation for keyword screening and blind sampling on another text. With the supplied example dictionary it selects 508 of the archived paragraphs. |
| `data/observed_rule_terms.csv` | All 131 distinct strings recorded in the specific-term-hit field of the rule-coding workbook, with paragraph counts. This downstream record contains observed hits. It cannot recover unused patterns or the full five-group source dictionary for initial candidate selection. |
| `method_and_prompts.md` | Four Turkish instructions printed in the author’s manuscript, English translations, and two clearly marked new templates for contextual tasks. |
| `figures/` | The workflow, keyword distribution and provisional classification figures, redrawn with English text. |
| `data/` | UTF-8 records extracted from the author’s study workbooks. File-specific provenance is given below. |

The archived records support exact recalculation of the reported counts. Re-executing the entire historical classification from the raw ebook would also require the historical thematic search code and full dictionary, the complete contextual prompt/response log, and the exact model snapshot. These items are not established by the available study materials.

## Data and coding stages

| CSV file | Record and source |
| --- | --- |
| `paragraphs.csv` | One original English paragraph per ID, from `Fen_Egitimi_Kesinlestirilmis_Analiz(1).xlsx`, sheet KORPUS_1680. Source text: Jules Verne, Project Gutenberg eBook 164, https://www.gutenberg.org/ebooks/164. |
| `screening.csv` | The 622-hit and 659-hit versions come from `Fen_Tam_Metin_Analizi(2).xlsx` and `Fen_Genisletilmis_Analiz(2).xlsx`. The candidate groups can overlap. Rule codes come from KORPUS_1680. The combined code and its source come from `Fen_Egitimi_Tek_Seferlik_Tam_Dogrulama(2).xlsx`. The later code comes from `Fen_Roman_1680_Paragraf_AI_Yeniden_Degerlendirme.xlsx`. The specific-term hits come from `Fen_NLP_Otomatik_On_Kodlama.xlsx`, TUM_KORPUS. |
| `pilot.csv` | The 50 records retain the initial blind human code, a separate AI contextual suggestion, the automated rule code, and the final reviewed code. The first, suggested and final fields were checked against the pilot and final-consensus workbooks, including `Fen_Pilot_50_Nihai_Uzlasma(2).xlsx`. Rule codes and the recorded reason come from PILOT_50 in the consolidated workbook. F1 = living organisms, F2 = natural environment, F3 = science and technology, F4 = earth/geosciences, EK = supplementary group. |
| `outcome_links.csv` | 86 proposed pairs and 62 scored pairs from `Fen_Egitimi_60_Baglam_ve_TYMM_Kontrol(1).xlsx`, sheets 05_MAARIF_ON_ADAY and 10_TYMM_INCELEME_60, joined by paragraph ID and outcome ID. An empty AI score denotes an unreviewed candidate. |
| `curriculum_units.csv` and `unit_links.csv` | Unit inventory and the 976 thematic links from `Fen_Tum_Maarif_Modeli_44_Unite_182_Cikti_Otomatik_Tarama.xlsx`. The unit-level records reflect topic retrieval. The outcome-level comparison is stored separately. |
| `curriculum_pilot.csv` | Separate 20-passage researcher-reviewed curriculum pilot from MEB_PILOT_20, cross-checked against `Maarif_Fen_Uzlasma_Kontrolu(4).xlsx`. Its rows are not added to the 62 scored pairs. |

The first rule-based pass assigned 148 direct, 495 indirect and 1,037 absent codes. The combined version used in the abstract retained 1,570 rule codes, 60 contextual AI codes and 50 researcher-reviewed pilot codes. Its totals were 162 direct, 474 indirect and 1,044 absent. A later automated re-screen assigned 234 direct, 383 indirect and 1,063 absent, changing 292 labels. None of these whole-corpus distributions provides independent human validation.

In the pilot, 26 of the 50 rule pre-codes matched the first blind human code. After the researcher reviewed the separate contextual AI suggestions, 29 rule pre-codes matched the final reviewed code. The 58% reported in the abstract refers to this second comparison. The same 50 passages support both calculations. The selection deliberately included keyword candidates and retrieval misses.
